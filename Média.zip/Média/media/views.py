from django.shortcuts import render

# Create your views here.

def media(requests):
    res = ''
    nota1 = ''
    nota2 = ''
    nota3 = ''
    nota4 = ''
    try:
        nota1 = eval(requests.GET.get('nota1'))
        nota2 = eval(requests.GET.get('nota2'))
        nota3 = eval(requests.GET.get('nota3'))
        nota4 = eval(requests.GET.get('nota4'))
        if requests.method=='GET':
            res = (nota1 + nota2 + nota3 + nota4) / 4
    except:
        print('Erro...')
    return render(requests, 'media.html',{'res':res, 'nota1':nota1, 'nota2':nota2, 'nota3':nota3, 'nota4':nota4})