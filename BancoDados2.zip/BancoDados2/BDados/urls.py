from django.urls import path
from .views import index, Prod

urlpatterns = [
    path('', index, name='index.html'),
    path('add-produto/', Prod, name='produto')
]
