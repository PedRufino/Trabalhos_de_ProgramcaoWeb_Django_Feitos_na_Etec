from stdimage.models import StdImageField
from django.db import models

class Produto(models.Model):
    id_Prod = models.AutoField(auto_created=True, primary_key=True, serialize=False)
    nome_prod = models.CharField(max_length=150, blank=True)
    estoque = models.IntegerField()
    preco = models.DecimalField(max_digits=8, decimal_places=2)
    image = StdImageField('Imagem', upload_to='produtos')
    
    def __str__(self):
        return self.nome_prod
