from .models import Produto
from django import forms

class ProdutoModelForm(forms.ModelForm):
    class Meta:
        model = Produto
        fields = ['nome_prod', 'preco', 'estoque', 'image']