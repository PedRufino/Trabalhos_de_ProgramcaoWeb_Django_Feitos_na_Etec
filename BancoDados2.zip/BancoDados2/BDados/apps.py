from django.apps import AppConfig


class BdadosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'BDados'
