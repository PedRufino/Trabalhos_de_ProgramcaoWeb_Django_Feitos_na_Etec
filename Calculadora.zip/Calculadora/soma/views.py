from django.shortcuts import render

# Create your views here.
def Soma(request):
    resultado =''
    num1=''
    num2=''
    try:
        # Tira informações do template e faz somas
        num1 = eval(request.GET.get('num1'))
        num2 = eval(request.GET.get('num2'))
        operacao=request.GET.get('operacao')
        if operacao=='+':
            resultado = num1+num2
        elif operacao=='-':
            resultado = num1-num2
        elif operacao=='*':
            resultado = num1*num2
        elif operacao=='/':
            if num2 == 0:
                resultado = 'Não existe divião por ZERO'
            else:
                resultado = num1/num2
        else:
            resultado = 'Escolha uma operação...'
    except:
        resultado = "Erro na operação..."
    return render(request, 'calculadora.html', {'resultado':resultado, 'num1':num1, 'num2':num2,'opt':'Somar'})