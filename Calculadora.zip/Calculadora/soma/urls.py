from django.urls import path
from .views import Soma

urlpatterns = [
    path('', Soma)
]
