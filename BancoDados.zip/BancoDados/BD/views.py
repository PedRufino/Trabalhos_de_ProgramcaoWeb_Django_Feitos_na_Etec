from django.shortcuts import render
from .models import Comentario
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect

# Create your views here.
@login_required(login_url='/login/')
def BD(request):
    list_itens = Comentario.objects.all()
    return render(request, 'index.html', {'lista_itens': list_itens})

def login_view(request):
    if request.method == 'GET':
        return render(request, 'login.html')
    username = request.POST['username']
    senha = request.POST['senha']
    user = authenticate(username=username, password=senha)
    if user:
        login(request,user)
    return HttpResponseRedirect('/')

def logout_view(request):
    logout(request)
    return HttpResponseRedirect('/')