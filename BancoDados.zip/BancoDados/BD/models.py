from django.db import models

class Comentario(models.Model):
    id = models.AutoField(primary_key=True)
    titulo = models.CharField(max_length=100)
    comentario = models.TextField()
    data = models.DateField(auto_now_add=100)
    hora = models.TimeField(auto_now_add=True)